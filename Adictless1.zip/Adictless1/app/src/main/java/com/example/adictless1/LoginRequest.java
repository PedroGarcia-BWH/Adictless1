package com.example.adictless1;

public class LoginRequest {
}
